package com.as.main.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.as.main.service.QRCodeService;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;

@Controller
public class QRCodeController {

    @Autowired
    private QRCodeService qrCodeService;

    @GetMapping("/cc")
    public String generateQRCode(HttpServletRequest httpServletRequest, Model model) throws UnknownHostException {
       
    	
    	
        String data = InetAddress.getLocalHost().getHostAddress() + ":" + httpServletRequest.getLocalPort() + "/form";
        
        
        String[] questions =
        	
        	{
            "What is the capital of France?",
            "Who discovered penicillin?",
            "What is the tallest mountain in the world?",
            "In which year did World War I begin?",
            "Who wrote 'Hamlet'?"
        };
        Random random = new Random();
        String randomQuestion = questions[random.nextInt(questions.length)];

       
        model.addAttribute("question", randomQuestion);

       
        model.addAttribute("qrCodeData", data);

        
        return "kbc";  
    }

    @GetMapping("/qr-image")
    public void getQRCode(HttpServletRequest httpServletRequest, HttpServletResponse response) throws UnknownHostException {
        String data = InetAddress.getLocalHost().getHostAddress() + ":" + httpServletRequest.getLocalPort() + "/form";
        
        try {
            
            response.setContentType("image/png");
            OutputStream outputStream = response.getOutputStream();
            qrCodeService.generateQRCode(data, outputStream, 300, 300);
            outputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

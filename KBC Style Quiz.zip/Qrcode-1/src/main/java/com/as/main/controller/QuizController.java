package com.as.main.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/quiz")
public class QuizController {

    private String[] questions = {
        "What is the capital of France?",
        "Who discovered penicillin?",
        "What is the tallest mountain in the world?",
        "In which year did World War I begin?",
        "Who wrote 'Hamlet'?"
    };

    private String[][] options = {
        {"Paris", "Berlin", "Madrid", "Rome"},
        {"Alexander Fleming", "Marie Curie", "Louis Pasteur", "Isaac Newton"},
        {"Mount Everest", "K2", "Kangchenjunga", "Lhotse"},
        {"1914", "1918", "1939", "1945"},
        {"William Shakespeare", "Charles Dickens", "J.K. Rowling", "Jane Austen"}
    };

    private int[] correctAnswers = {0, 0, 0, 0, 0}; 

    @GetMapping("/{questionNumber}")
    public String getQuestion(@PathVariable int questionNumber, Model model) {
        if (questionNumber < 1 || questionNumber > questions.length) {
            return "redirect:/result";  
        }

        model.addAttribute("question", questions[questionNumber - 1]);
        model.addAttribute("options", options[questionNumber - 1]);
        model.addAttribute("questionNumber", questionNumber);

        return "quiz";  
    }

    @PostMapping("/submitAnswer")
    public String checkAnswer(@RequestParam int questionNumber, @RequestParam int answer, Model model) {
        String message;
        if (answer == correctAnswers[questionNumber - 1]) {
            message = "Congratulations! You answered correctly!";
            model.addAttribute("nextQuestion", questionNumber + 1);
        } else {
            message = "Sorry, that's incorrect.";
            model.addAttribute("nextQuestion", questionNumber);
        }

        model.addAttribute("message", message);
        return "result";  
    }
}

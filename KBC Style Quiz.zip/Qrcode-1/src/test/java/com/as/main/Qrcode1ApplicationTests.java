package com.as.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qrcode1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
